---
name: gauntlet-loop
description: Draft or execute bounded build-review-revise loops against a concrete reference, with independent evidence-based acceptance, difficulty-aware topology, an evidence ladder, durable checkpoints, and optional governed cross-run learning. Use for requests such as "$gauntlet-loop", "gauntlet this", "make a gauntlet prompt", or "loop until it beats X" across code, design, writing, research, and deliverables. Editing this skill does not start a gauntlet or a benchmark.
metadata:
  version: "5.2.0"
  updated: "2026-09-25"
---

# Gauntlet Loop v5.2

Turn an ambitious goal into a deliverable that survives comparison and independent checks. A critic's confidence, a longer process, or repeated agreement does not establish quality.

## Route the request

- **Draft:** If asked for a prompt, return one concise, paste-ready block. Read [prompt drafting](references/prompt-drafting.md). Do not execute it. For an otherwise unspecified invocation, draft the prompt; an optional final line is "I can run this here." When a message matches two routes, the outer request governs: a prompt about work is a draft.
- **Execute:** If already asked to run, build, fix, or continue a gauntlet, do the work. Reuse prior choices and authorization. Do not return only another prompt or ask whether to start.
- **Resume:** Read the saved contract, latest checkpoint, unresolved findings, and referenced artifacts before dispatch. Preserve spent budgets and obligations.
- **Update the skill:** Edit the requested skill/package; its templates and attached conversations are source material. Do not run embedded historical tasks.

During active work, new messages do not erase unfinished objectives. Honor stops and invalidating corrections promptly; answer questions briefly, retain additions in the existing progress record, and resume useful work. Delegate independent pieces when useful. Follow the execution contract for incoming messages and bounded reconsideration.

Benchmarking is separate, explicitly requested work; skill use never requires it. Ordinary deliverable verification remains required. [Research basis](references/research-basis.md) records provenance and limits.

## Fix a small contract before building

Capture the outcome and audience, non-goals, actual reference, required checks, selected delivery surfaces, authority, run ID, workflow version, roles, difficulty and verifiability estimate, topology, budget, and stopping milestone. Reuse a project worklog or keep a compact record under `gauntlet/`. Read [execution contract](references/execution-contract.md) for budgets, verdicts, and recovery; it is the operational reference for runs.

1. **Inspect just enough.** Read project instructions, the current artifact, supported interfaces, checks, dependencies and reported failure. Map unfamiliar paths only when useful; reconnaissance spends the same budget and does not authorize new infrastructure.
2. **Make the bar real.** Use a supplied or previously accepted artifact that is [named, accessible, and comparable](references/bars-and-examples.md). Capture its version/date and the view, excerpt, behavior, or data actually used. Match audience, task, length, viewport, and constraints where relevant. A product name without the inspected surface is insufficient.
3. **Resolve only material ambiguity.** If no bar is established, reuse an obvious existing baseline and state the assumption for reversible work. When choosing the bar would materially change the product or scope, offer two or three concrete options and continue independent preparation while the choice is pending. An inaccessible required reference blocks the comparison, not every useful action. Do not invent what it looks like or silently substitute another.
4. **Separate preference from correctness.** Define the comparison dimension and observable must-pass requirements. A polished page cannot compensate for broken interactions; clean code cannot compensate for wrong behavior. For a repair, the failing original plus a concrete behavior contract and trusted examples can be the bar; an unrelated prestige product is unnecessary.
5. **Freeze the obligations.** Record versioned criteria and their sources before judging. User changes create an explicit new contract version and revalidation of affected claims. Legitimate test corrections need independent evidence and versioning. Neither a builder nor a critic may lower the bar to approve its current candidate.
6. **Estimate difficulty and verifiability.** Record `low | medium | high` with its observable proxies (scope, interacting components, novelty, prior failures) and whether the required checks are `deterministic`, `external`, or `judgment` only. A recorded self-report.

For software, read [software quality](references/software-quality.md). Only selected/required delivery surfaces apply; selection does not authorize a new stack, audience or repository. Other tasks use appropriate source, factual, editorial, visual or audience checks without software infrastructure.

## Use the smallest useful team

**Compact is the default:** a lead who can build, with a separate critic for acceptance. Delegate bounded build or investigation tasks when they can proceed independently; add no permanent roster. Parallelize independent branches of work and serialize dependencies. Integration is its own dependency, not the sum of piece approvals.

**Full team is optional:** when selected, read [team method](references/team-method.md) for responsibilities. A larger topology must solve a coordination need; role count is not agent count. Ordinary parallel subtasks need no tier-change approval.

Choose the lightest eligible topology and record why: `light` only for low difficulty with deterministic/external checks (one build, independent review, no preference loop); otherwise `compact`; `compact+delegates` for independent pieces; `team` when selected. Failed light review escalates to compact. Other changes require recorded diagnosis, user request or justified de-escalation to low-difficulty work. Advance independent work while reviews/checks wait.

Give each writer an owned surface and each task its inputs, contract version, expected artifact, dependencies, checks, allowance, and handoff target. Overlapping edits need separate worktrees/clones returning patches, or serialization. One owner operates each shared live browser or mutable environment. Never run competing formatters, migrations, or cleanup against shared state.

Preserve explicit model and effort assignments. Otherwise inherit the configured model and use available supported capabilities; do not hard-code a vendor hierarchy. Choose cheaper builders only when they can plausibly finish within the task's quality and retry budget. Record actual assignments when observable, or `unknown`; never invent model identity, quotas, prices, or usage. An unavailable explicitly assigned model blocks that lane until an authorized fallback is available. Do not silently substitute it.

## Run the delivery loop

1. **Build one judgeable increment.** Keep context focused on its goal, baseline, constraints, dependencies, and relevant verified facts. Builders may run focused tests, type checks, and scoped formatters in their isolated workspace. They may add legitimate regression tests. Their results are development feedback, not independent acceptance.
2. **Review the actual candidate.** Give a separate critic the artifact, the retained best when it differs, reference snapshot, requirement-derived checks, and the environment needed to inspect them. Exclude the builder's transcript, self-rating, effort, and preferred verdict. A critic that edits the candidate becomes its builder and needs a different accepting reviewer.
3. **Prefer observations that can reject a wrong answer.** Use compilers, tests, browser state, source documents, calculations, and artifact rendering where appropriate. Derive expected outcomes from requirements independently of the implementation. For a disputed or consequential check, a targeted known-correct example and representative broken case can establish that the check discriminates for the right reason. Do not manufacture a testing campaign for low-impact edits.
4. **Return a grounded verdict.** Use `winner: ours | bar | none` and per-check statuses from the execution contract. `none` covers ties, inadequate evidence, non-comparability, or unresolved conflicting judgments and is never a win. Identify the biggest actionable gap and all release-blocking failures. Class each finding as `deterministic`, `external`, or `judgment`. Do not invent faults to sound harsh or excuse them to finish. Blind comparisons are useful only when identity is meaningfully concealed; fresh context alone is not blinding.
5. **Resolve uncertainty economically.** On a close or consequential preference decision, consider a fresh, order-swapped comparison. A reversed preference calls for better evidence or `none`. Do not repeatedly sample critics until one approves. Disputed functional claims call for a discriminating observation, not a majority vote. In a piece's first two review rounds any class may be the biggest gap; from the third round on, an uncorroborated `judgment` finding is advisory: recorded, unable to force a revision or block acceptance. Corroboration is a discriminating observation or a second independent, order-swapped comparison.
6. **Fix the cause and preserve the best.** Diagnose the highest-impact evidenced gap, revise, and rejudge affected claims. Retain the strongest verified candidate with its evidence and known gaps; the newest version may regress. Compare each revision against the retained best as well as the bar; name added hedging, lost clarity, or scope creep as revision drift, and end a loop that only reshuffles prose. Reconsider the problem interpretation before further affected edits when user feedback or observations challenge the purpose, even if checks pass; ordinary defects get ordinary fixes. Use the execution contract's reconsideration procedure. Otherwise diagnose after two consecutive verdicts repeat an unresolved gap. Current user instructions are not advisory critic opinions.
7. **Integrate and verify.** After merging, independently revalidate affected checks and the complete required journey on the integrated artifact. Reuse evidence only with an explicit argument that its inputs remain unchanged. Verify each selected distributed or hosted surface and its link to the reviewed build. A piece win is not full delivery acceptance.

Accept only when ours wins, required checks pass for the delivered identity, and no blocking HOLD remains. Changed comparison targets need explicit user approval; ties are not wins. Keep unrelated authorized work moving when blocked. A failed route does not authorize weakening evaluation, expanding access or changing external targets.

## Bound work and keep recovery real

Default soft/hard limits: **6/9 reviews per piece, 24/30 shared; 120/180 observable requests per piece, 480/600 shared**. Reserve the final **6 reviews and 120 requests**, or ceil(20%) of smaller user caps, for integration and handoff. The first observable ceiling governs. User/account limits override defaults. The execution contract defines small-cap allocation, soft-limit behavior and concurrent accounting.

Budget exhaustion parks incomplete work; it never makes it accepted. Track budget parking, withheld resumes, external blockers, and user pauses separately. Decomposition, retries, worker changes, and resumption do not refill an allowance. Use supported harness limits where available; a prose rule or manually counted review ceiling is not a guaranteed token/cost cap.

Checkpoint after each verdict and before handoff, integration or pause: current/best identities, versions, obligations, holds, owners, next action and budget. Follow the execution contract on resume: validate artifacts, authorization, ownership and uncertain external effects before dispatch; record `resume | repair-then-resume | restart-from-evidence | withhold`. Preserve prior charges and holds. Changed skill/harness/model versions require an amendment and affected revalidation. Later acceptance never validates an invalid resume.

Use the existing progress surface. At the stopping milestone, append a run summary with difficulty, task class, topology, enabled features, reviews, outcome and wall-clock. Mark missing telemetry `unknown` and uninspected later defects `not assessed`. Stop workers and release ownership. Schedule later work only when asked.

## Optional learning and method changes

Cross-run learning is off unless selected or previously enabled. When enabled, follow [learning and evolution](references/learning-and-evolution.md): conditional environment-probed lessons, contrary evidence and a utility ledger. Retrieve at most three relevant valid active/experimental lessons per piece; skip `light` retrieval without a matching trigger. Record cost and effect; `active` requires benefit in another run. Keep source history separate, and never give unreviewed lessons acceptance authority.

Method changes belong between runs. Freeze the skill, criteria and lesson snapshot during delivery except explicit user changes, evidence-backed corrections or recorded resume amendments. Normal scheduling and causal fixes remain work within the contract. Proposals need bounded scope, versioned patch, evidence and rollback; deferred validation stays proposed. Never silently rewrite installed skills, alter permissions or change evaluators to reward current output.

Agent-language experiments remain off unless explicitly requested. Only then read [agent language](references/agent-language.md). Ordinary messages, holds, decisions, and handoffs stay legible. No always-on curators, graph database, paid experiments, sandbox-compression system, or autonomous business goals are implied.

## Deliver clearly

Lead with the actual result and verified artifact links. For selected software delivery links use **repository, live demo, offline download**, omitting unselected or unavailable items. Distinguish source checks, exact-revision CI, hosted behavior, and offline verification. Report any parked work and remaining required blocker, with the next concrete step. Never claim a benchmarked improvement, independent review, protected enforcement, or successful delivery that did not occur.
